﻿using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;
using IO.Swagger.SharpModel;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var updateManager = UpdateManager.Instance;
            
            updateManager.getInitialServerUpdates();
            
            var instances = updateManager.instances;

            var instanceTypes = InstanceType.getInstanceTypes();

            var studentType = instanceTypes.Where(x => x.Name == "Student").First();

            Console.WriteLine("-----------------Creating instances-----------------");
            for (int i = 0; i < 5; i++)
            {
                instances.Add(Instance.create(studentType, "st" + i.ToString()));
            }

            foreach (var instance in instances)
            {
                Console.WriteLine(instance.Name);
            }


            Console.WriteLine("-----------------Setting properties of 3 instances-----------------");

            for (int i = 0; i<2; i++)
            {
                var instanceProperties = Property.getProperties(instances[i]);

                Property.set(instanceProperties.Where(x => x.Name == "name").First(), instances[i], "John Doe");
            }

            foreach (var instance in instances)
            {
                Console.WriteLine(instance.Name);
            }

            Console.WriteLine("-----------------Local Instances-----------------");

            foreach (var instance in instances)
            {
                Console.WriteLine($"Id:{instance.Id}   Name:{instance.Name}");
            }


            Console.WriteLine("-----------------All Instances From Bridge-----------------");

            var allInstances = Instance.getInstances(studentType);

            foreach (var instance in allInstances)
            {
                Console.WriteLine($"Id:{instance.Id}   Name:{instance.Name}");
            }


            Console.WriteLine("-----------------Conclude-----------------");

            updateManager.conclude();

            foreach (var instance in instances)
            {
                Console.WriteLine($"Id:{instance.Id}   Name:{instance.Name}");
            }


            Console.WriteLine("-----------------Deleting instances-----------------");

            foreach (var instance in instances)
            {
                instance.delete();
            }

            Console.WriteLine($"Instances:{0}", instances.Count);
        }
    }
}
